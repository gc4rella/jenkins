#!/bin/bash

#Start sipp server
screen -d -m -S server sipp -sn uas
